package com.example.mtracker.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.mtracker.R;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityManageStudentsBinding;
import com.example.mtracker.adapters.UserAdapter;
import com.example.mtracker.models.User;
import java.util.ArrayList;
import java.util.List;

public class ManageStudentsActivity extends AppCompatActivity {
    private ActivityManageStudentsBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private UserAdapter adapter;
    private List<User> studentList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityManageStudentsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupRecyclerView();
        setupListeners();
        loadStudents(true);
    }

    private void setupRecyclerView() {
        adapter = new UserAdapter(studentList, this::showDeleteConfirmation);
        binding.rvStudents.setLayoutManager(new LinearLayoutManager(this));
        binding.rvStudents.setAdapter(adapter);
    }

    private void setupListeners() {
        binding.btnBack.setOnClickListener(v -> finish());
        binding.swipeRefresh.setOnRefreshListener(() -> loadStudents(false));
        binding.btnDeleteAll.setOnClickListener(v -> showDeleteAllConfirmation());
    }

    private void loadStudents(boolean showLoader) {
        if (showLoader) binding.progressBar.setVisibility(View.VISIBLE);
        firebaseManager.getAllStudents(students -> {
            binding.progressBar.setVisibility(View.GONE);
            binding.swipeRefresh.setRefreshing(false);
            studentList = students;
            adapter.updateList(studentList);
        });
    }

    private void showDeleteConfirmation(User user) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_student_title)
                .setMessage(getString(R.string.delete_student_msg, user.getUsername()))
                .setPositiveButton(R.string.delete, (dialog, which) -> deleteUser(user))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showDeleteAllConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_all_students_title)
                .setMessage(R.string.delete_all_students_msg)
                .setPositiveButton(R.string.delete_all, (dialog, which) -> deleteAllStudents())
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void deleteUser(User user) {
        binding.progressBar.setVisibility(View.VISIBLE);
        firebaseManager.deleteUser(user.getId(), success -> {
            binding.progressBar.setVisibility(View.GONE);
            if (success) {
                Toast.makeText(this, R.string.student_deleted, Toast.LENGTH_SHORT).show();
                loadStudents(false);
            } else {
                Toast.makeText(this, R.string.failed_delete_student, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteAllStudents() {
        binding.progressBar.setVisibility(View.VISIBLE);
        firebaseManager.deleteAllStudents(success -> {
            binding.progressBar.setVisibility(View.GONE);
            if (success) {
                Toast.makeText(this, R.string.all_students_deleted, Toast.LENGTH_SHORT).show();
                loadStudents(false);
            } else {
                Toast.makeText(this, R.string.failed_delete_all, Toast.LENGTH_SHORT).show();
            }
        });
    }
}

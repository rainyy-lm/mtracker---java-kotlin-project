package com.example.mtracker.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.example.mtracker.databinding.ActivitySettingsBinding;

public class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding binding;
    private SharedPreferences sharedPreferences;
    private String userRole;
    private String username;
    private String idNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userRole = getIntent().getStringExtra("USER_ROLE");
        username = getIntent().getStringExtra("USERNAME");
        idNumber = getIntent().getStringExtra("ADMIN_NUMBER");

        sharedPreferences = getSharedPreferences("ThemePrefs", Context.MODE_PRIVATE);
        
        setupThemeSelection();
        setupAdminTools();
        setupProfile();
        
        binding.btnBack.setOnClickListener(v -> finish());
    }

    private void setupProfile() {
        binding.llUserProfile.setVisibility(View.VISIBLE);
        binding.tvUserName.setText(username != null ? username : "User");
        binding.tvUserRole.setText(userRole != null ? userRole : "Unknown Role");
        
        if (idNumber != null && !idNumber.isEmpty()) {
            binding.tvUserNumber.setText("ID: " + idNumber);
        } else {
            String fallbackPrefix = "Admin".equals(userRole) ? "ADM" : "STU";
            binding.tvUserNumber.setText("ID: " + fallbackPrefix + "-???");
        }
    }

    private void setupAdminTools() {
        if ("Admin".equals(userRole)) {
            binding.llAdminTools.setVisibility(View.VISIBLE);
            binding.btnCreateAdmin.setOnClickListener(v -> {
                Intent intent = new Intent(this, RegisterActivity.class);
                intent.putExtra("IS_INTERNAL_ADMIN_CREATE", true);
                startActivity(intent);
            });
            binding.btnManageStudents.setOnClickListener(v -> {
                Intent intent = new Intent(this, ManageStudentsActivity.class);
                startActivity(intent);
            });
        } else {
            binding.llAdminTools.setVisibility(View.GONE);
        }
    }

    private void setupThemeSelection() {
        int currentTheme = sharedPreferences.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        
        if (currentTheme == AppCompatDelegate.MODE_NIGHT_NO) {
            binding.rbLight.setChecked(true);
        } else if (currentTheme == AppCompatDelegate.MODE_NIGHT_YES) {
            binding.rbDark.setChecked(true);
        } else {
            binding.rbSystem.setChecked(true);
        }

        binding.rgTheme.setOnCheckedChangeListener((group, checkedId) -> {
            int mode;
            if (checkedId == binding.rbLight.getId()) {
                mode = AppCompatDelegate.MODE_NIGHT_NO;
            } else if (checkedId == binding.rbDark.getId()) {
                mode = AppCompatDelegate.MODE_NIGHT_YES;
            } else {
                mode = AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
            }
            
            sharedPreferences.edit().putInt("theme_mode", mode).apply();
            AppCompatDelegate.setDefaultNightMode(mode);
        });
    }
}

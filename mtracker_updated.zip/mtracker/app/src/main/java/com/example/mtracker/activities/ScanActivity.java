package com.example.mtracker.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityCompat.OnRequestPermissionsResultCallback;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.mtracker.adapters.ScannedItemAdapter;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityScanBinding;
import com.example.mtracker.models.InventoryItem;
import com.example.mtracker.models.Transaction;
import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;
import com.journeyapps.barcodescanner.camera.CameraSettings;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ScanActivity extends AppCompatActivity {
    private ActivityScanBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private String userRole = null;
    private String username = null;
    private String idNumber = null;
    private boolean isFlashOn = false;

    private final Map<String, InventoryItem> borrowList = new HashMap<>();
    private ScannedItemAdapter scannedItemAdapter;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityScanBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userRole = getIntent().getStringExtra("USER_ROLE");
        username = getIntent().getStringExtra("USERNAME");
        idNumber = getIntent().getStringExtra("ADMIN_NUMBER");

        binding.btnBack.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        setupScanner();
        setupRecyclerView();

        if (checkCameraPermission()) {
            startScanning();
        } else {
            requestCameraPermission();
        }

        setupButtons();
        updateUI();
    }

    private void setupRecyclerView() {
        scannedItemAdapter = new ScannedItemAdapter(new ArrayList<>(), item -> {
            borrowList.remove(item.getQrCode());
            updateUI();
        });
        binding.rvScannedItems.setLayoutManager(new LinearLayoutManager(this));
        binding.rvScannedItems.setAdapter(scannedItemAdapter);
    }

    private void setupScanner() {
        CameraSettings settings = new CameraSettings();
        settings.setAutoFocusEnabled(true);
        settings.setContinuousFocusEnabled(true);
        binding.barcodeScanner.getBarcodeView().setCameraSettings(settings);
        binding.barcodeScanner.getBarcodeView().setDecoderFactory(new DefaultDecoderFactory());
        binding.barcodeScanner.setStatusText("Place the QR code inside the rectangle to scan");

        binding.btnFlash.setOnClickListener(v -> {
            if (isFlashOn) {
                binding.barcodeScanner.setTorchOff();
                binding.btnFlash.setImageResource(android.R.drawable.ic_menu_compass);
            } else {
                binding.barcodeScanner.setTorchOn();
                binding.btnFlash.setImageResource(android.R.drawable.ic_menu_mylocation);
            }
            isFlashOn = !isFlashOn;
        });
    }

    private void startScanning() {
        binding.barcodeScanner.decodeContinuous(new BarcodeCallback() {
            @Override
            public void barcodeResult(BarcodeResult result) {
                if (result.getText() != null) {
                    String scannedData = result.getText().trim();
                    binding.barcodeScanner.pause();
                    handleScannedQR(scannedData);
                }
            }
            @Override
            public void possibleResultPoints(List<com.google.zxing.ResultPoint> resultPoints) {}
        });
    }

    private void handleScannedQR(String qrData) {
        firebaseManager.getItemByQR(qrData, item -> {
            if (item == null) {
                showToast("Unknown Item QR: " + qrData);
                resumeScanner();
                return;
            }

            if ("Defective".equalsIgnoreCase(item.getCondition()) || "Defective".equalsIgnoreCase(item.getStatus())) {
                new AlertDialog.Builder(this)
                        .setTitle("System Report")
                        .setMessage("This Item (" + item.getItemName() + ") is Defective")
                        .setPositiveButton("OK", (d, w) -> resumeScanner())
                        .setCancelable(false)
                        .show();
                return;
            }

            firebaseManager.getActiveTransactionForItem(qrData, transaction -> {
                if (transaction != null) {
                    showReturnChoiceDialog(item, transaction);
                } else {
                    if (!borrowList.containsKey(qrData)) {
                        borrowList.put(qrData, item);
                        showToast("Added " + item.getItemName() + " to list");
                    } else {
                        showToast("Item already in list");
                    }
                    updateUI();
                    resumeScanner();
                }
            });
        });
    }

    private void showReturnChoiceDialog(InventoryItem item, Transaction transaction) {
        String[] choices = {"Good Condition", "Defect"};
        new AlertDialog.Builder(this)
                .setTitle("Return Item: " + item.getItemName())
                .setItems(choices, (dialog, which) -> {
                    String condition = (which == 0) ? "Good" : "Defective";
                    processReturn(item, transaction, condition);
                })
                .setNegativeButton("Cancel", (d, w) -> resumeScanner())
                .setCancelable(false)
                .show();
    }

    private void processReturn(InventoryItem item, Transaction transaction, String condition) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date now = new Date();

        boolean overdueCheck = false;
        try {
            Date dueDate = sdf.parse(transaction.getDueDate());
            if (dueDate != null && now.after(dueDate)) {
                overdueCheck = true;
                showToast("Item is past the return date");
            }
        } catch (Exception ignored) {}

        final boolean isOverdue = overdueCheck;
        String returnStatus = isOverdue ? "Returned (Overdue)" : "Returned";
        transaction.setStatus(returnStatus);
        transaction.setConditionOnReturn(condition);
        transaction.setDate(sdf.format(now));

        firebaseManager.addTransaction(transaction, success -> {
            if (success) {
                String itemStatus = "Defective".equals(condition) ? "Defective" : "Available";
                firebaseManager.updateItemStatus(item.getId(), itemStatus, condition, updateSuccess -> {
                    showToast("Item Returned as " + condition + (isOverdue ? " (LATE)" : ""));
                    resumeScanner();
                });
            }
        });
    }

    private void setupButtons() {
        binding.btnBorrow.setOnClickListener(v -> {
            if (borrowList.isEmpty()) {
                showToast("Scan items first");
                return;
            }
            showStudentNumberDialog();
        });

        binding.btnRescan.setOnClickListener(v -> {
            borrowList.clear();
            updateUI();
            binding.barcodeScanner.resume();
        });
    }

    private void showStudentNumberDialog() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("Student Number (e.g. STU-001)");

        new AlertDialog.Builder(this)
                .setTitle("Borrow Request")
                .setMessage("Enter the Student Number who is borrowing these " + borrowList.size() + " items:")
                .setView(input)
                .setPositiveButton("Send Request", (dialog, which) -> {
                    String studentId = input.getText().toString().trim();
                    if (!studentId.isEmpty()) {
                        sendRequestToStudent(studentId);
                    } else {
                        showToast("ID Number required");
                        resumeScanner();
                    }
                })
                .setNegativeButton("Cancel", (d, w) -> resumeScanner())
                .show();
    }

    private void sendRequestToStudent(String studentId) {
        List<InventoryItem> items = new ArrayList<>(borrowList.values());
        firebaseManager.createBorrowRequest(studentId, items, requestId -> {
            if (requestId != null) {
                showToast("Request sent to Student " + studentId);
                borrowList.clear();
                updateUI();
                finish();
            } else {
                showToast("Failed to send request");
                resumeScanner();
            }
        });
    }

    private void updateUI() {
        List<InventoryItem> list = new ArrayList<>(borrowList.values());
        scannedItemAdapter.updateList(list);

        if (borrowList.isEmpty()) {
            binding.itemCard.setVisibility(View.GONE);
            binding.tvStatus.setText("Point camera at QR Code");
            binding.tvStatus.setTextColor(Color.parseColor("#60A5FA"));
        } else {
            binding.itemCard.setVisibility(View.VISIBLE);
            binding.tvScanItemName.setText("Items to Borrow (" + borrowList.size() + ")");
            
            binding.btnBorrow.setText("Borrow All");
            binding.btnBorrow.setVisibility(View.VISIBLE);
            binding.btnReturn.setVisibility(View.GONE);
            binding.btnRescan.setText("Clear List");
        }
    }

    private void resumeScanner() {
        binding.barcodeScanner.postDelayed(() -> binding.barcodeScanner.resume(), 1000);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private boolean checkCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                binding.barcodeScanner.resume();
            } else {
                showToast("Camera permission required");
                finish();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkCameraPermission()) binding.barcodeScanner.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        binding.barcodeScanner.pause();
    }
}

package com.example.mtracker.adapters;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.example.mtracker.R;
import com.example.mtracker.databinding.ItemInventoryBinding;
import com.example.mtracker.models.InventoryItem;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private List<InventoryItem> items;
    private final boolean isAdmin;
    private final String currentUserId;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onEditClick(InventoryItem item);
        void onDeleteClick(InventoryItem item);
    }

    public InventoryAdapter(List<InventoryItem> items, boolean isAdmin, String currentUserId,
                            OnItemClickListener listener) {
        this.items = items;
        this.isAdmin = isAdmin;
        this.currentUserId = currentUserId;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final ItemInventoryBinding binding;
        public ViewHolder(ItemInventoryBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemInventoryBinding binding = ItemInventoryBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.binding.tvItemName.setText(item.getItemName());
        
        // Highlight Category
        String category = item.getCategory();
        holder.binding.tvCategory.setText(category != null ? category.toUpperCase() : "NONE");
        highlightCategory(holder.binding.tvCategory, category);

        holder.binding.tvQrDisplay.setText("ID: " + item.getQrCode());
        holder.binding.tvCondition.setText("Condition: " + (item.getCondition() != null ? item.getCondition() : "N/A"));

        boolean isBorrower = currentUserId != null && currentUserId.equals(item.getBorrowerId());

        if (item.isOverdue() && (isAdmin || isBorrower)) {
            holder.binding.tvStatus.setText("OVERDUE");
            holder.binding.tvStatus.setTextColor(Color.RED);
        } else {
            holder.binding.tvStatus.setText(item.getStatus());
            if ("Defective".equalsIgnoreCase(item.getStatus()) || "Defective".equalsIgnoreCase(item.getCondition())) {
                holder.binding.tvStatus.setTextColor(Color.parseColor("#EF4444")); // Red
            } else if ("On Hold".equalsIgnoreCase(item.getStatus()) || "On Hold".equalsIgnoreCase(item.getCondition())) {
                holder.binding.tvStatus.setTextColor(Color.parseColor("#F59E0B")); // Orange/Amber
            } else if ("Available".equalsIgnoreCase(item.getStatus())) {
                holder.binding.tvStatus.setTextColor(Color.parseColor("#10B981")); // Green
            } else {
                holder.binding.tvStatus.setTextColor(Color.parseColor("#60A5FA")); // Blue for Borrowed
            }
        }

        if ((isAdmin || isBorrower) && "Borrowed".equalsIgnoreCase(item.getStatus())) {
            holder.binding.llBorrowerInfo.setVisibility(View.VISIBLE);
            holder.binding.tvBorrowerName.setText("Borrower: " + (isBorrower ? "You" : item.getBorrowerName()));
            holder.binding.tvDueDate.setText("Due: " + item.getDueDate());
            
            if (item.isOverdue()) {
                holder.binding.tvDueDate.setTextColor(Color.RED);
            } else {
                holder.binding.tvDueDate.setTextColor(Color.parseColor("#94A3B8"));
            }
        } else {
            holder.binding.llBorrowerInfo.setVisibility(View.GONE);
        }

        if (isAdmin) {
            holder.binding.llAdminActions.setVisibility(View.VISIBLE);
            holder.binding.btnEdit.setOnClickListener(v -> {
                if (listener != null) listener.onEditClick(item);
            });
            holder.binding.btnDelete.setOnClickListener(v -> {
                if (listener != null) listener.onDeleteClick(item);
            });
        } else {
            holder.binding.llAdminActions.setVisibility(View.GONE);
        }
    }

    private void highlightCategory(View view, String category) {
        if (category == null) return;
        
        int color;
        String catLower = category.toLowerCase();
        
        if (catLower.contains("consumable")) {
            color = Color.parseColor("#3B82F6"); // Blue
        } else if (catLower.contains("equipment")) {
            color = Color.parseColor("#10B981"); // Green
        } else if (catLower.contains("part")) {
            color = Color.parseColor("#8B5CF6"); // Purple
        } else if (catLower.contains("board")) {
            color = Color.parseColor("#06B6D4"); // Cyan/Teal
        } else {
            color = Color.parseColor("#6B7280"); // Gray
        }

        GradientDrawable background = (GradientDrawable) ContextCompat.getDrawable(view.getContext(), R.drawable.bg_category_chip);
        if (background != null) {
            background.setColor(color);
            view.setBackground(background);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void updateList(List<InventoryItem> newList) {
        this.items = newList;
        notifyDataSetChanged();
    }
}

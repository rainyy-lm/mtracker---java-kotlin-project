package com.example.mtracker.models;

public class User {
    private String id;
    private String username;
    private String password;
    private String role; // "Admin" or "Student"
    private String adminNumber; // format: ADM-001

    public User() {
        this.id = "";
        this.username = "";
        this.password = "";
        this.role = "";
        this.adminNumber = "";
    }

    public User(String id, String username, String password, String role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.adminNumber = "";
    }

    public User(String id, String username, String password, String role, String adminNumber) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.adminNumber = adminNumber;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getAdminNumber() { return adminNumber; }
    public void setAdminNumber(String adminNumber) { this.adminNumber = adminNumber; }
}

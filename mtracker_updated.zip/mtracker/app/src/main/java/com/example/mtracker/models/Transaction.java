package com.example.mtracker.models;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Transaction {
    private String id;
    private String studentName;
    private String studentId;
    private String itemName;
    private String qrCode; // Added to track specific unique items
    private int quantity;
    private String date;
    private String status; // "Borrowed", "Returned", "Overdue"
    private String dueDate; // Expected return date
    private String conditionOnReturn; // "Good" or "Defective"

    public Transaction() {
        this.id = "";
        this.studentName = "";
        this.studentId = "";
        this.itemName = "";
        this.qrCode = "";
        this.quantity = 0;
        this.date = "";
        this.status = "";
        this.dueDate = "";
        this.conditionOnReturn = "";
    }

    public Transaction(String id, String studentName, String studentId, String itemName, String qrCode, int quantity, String date, String status, String dueDate) {
        this.id = id;
        this.studentName = studentName;
        this.studentId = studentId;
        this.itemName = itemName;
        this.qrCode = qrCode;
        this.quantity = quantity;
        this.date = date;
        this.status = status;
        this.dueDate = dueDate;
        this.conditionOnReturn = "";
    }

    // Constructor for SQLite compatibility
    public Transaction(String id, String studentName, String studentId, String itemName, int quantity, String date, String status) {
        this.id = id;
        this.studentName = studentName;
        this.studentId = studentId;
        this.itemName = itemName;
        this.qrCode = "";
        this.quantity = quantity;
        this.date = date;
        this.status = status;
        this.dueDate = "";
        this.conditionOnReturn = "";
    }

    public boolean isOverdue() {
        if (!"Borrowed".equalsIgnoreCase(status) || dueDate == null || dueDate.isEmpty()) {
            return false;
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date due = sdf.parse(dueDate);
            return due != null && new Date().after(due);
        } catch (Exception e) {
            return false;
        }
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getDueDate() { return dueDate; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }

    public String getConditionOnReturn() { return conditionOnReturn; }
    public void setConditionOnReturn(String conditionOnReturn) { this.conditionOnReturn = conditionOnReturn; }
}

package com.example.mtracker.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityAddItemBinding;
import com.example.mtracker.models.InventoryItem;

public class AddItemActivity extends AppCompatActivity {
    private ActivityAddItemBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private boolean isEditMode = false;
    private String itemId;
    private String userRole;
    private final int currentQty = 1; // Default to 1 for individual tracking (Part 1.1)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddItemBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        isEditMode = getIntent().getBooleanExtra("IS_EDIT", false);
        itemId = getIntent().getStringExtra("ITEM_ID");
        userRole = getIntent().getStringExtra("USER_ROLE");

        setupUI();
        setupDropdowns();

        binding.btnBack.setOnClickListener(v -> {
            getOnBackPressedDispatcher().onBackPressed();
        });

        binding.btnAddItem.setOnClickListener(v -> {
            handleSave();
        });
    }

    private void setupDropdowns() {
        // Condition Dropdown
        String[] conditions = {"Good", "Defective", "On Hold"};
        ArrayAdapter<String> conditionAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, conditions);
        binding.actvCondition.setAdapter(conditionAdapter);
        if (!isEditMode) {
            binding.actvCondition.setText(conditions[0], false); // Default to Good
        }

        // Category Dropdown
        String[] categories = {"Consumable", "Equipment", "Part", "Board"};
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, categories);
        binding.actvCategory.setAdapter(categoryAdapter);
    }

    private void setupUI() {
        if (isEditMode) {
            binding.tvTitle.setText("Edit Item");
            binding.btnAddItem.setText("Update Item");
            binding.etItemName.setText(getIntent().getStringExtra("ITEM_NAME"));
            
            String category = getIntent().getStringExtra("ITEM_CATEGORY");
            if (category != null) {
                binding.actvCategory.setText(category, false);
            }
            
            binding.etQR.setText(getIntent().getStringExtra("ITEM_QR"));
            String condition = getIntent().getStringExtra("ITEM_CONDITION");
            if (condition != null) {
                binding.actvCondition.setText(condition, false);
            }

            double price = getIntent().getDoubleExtra("ITEM_PRICE", 0.0);
            binding.etPrice.setText(String.valueOf(price));
        }

        if (!"Admin".equals(userRole)) {
            binding.btnAddItem.setVisibility(View.GONE);
            binding.tilCondition.setEnabled(false);
            binding.tilCategory.setEnabled(false);
            Toast.makeText(this, "Admin access required", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleSave() {
        String name = binding.etItemName.getText().toString().trim();
        String category = binding.actvCategory.getText().toString().trim();
        String qr = binding.etQR.getText().toString().trim();
        String condition = binding.actvCondition.getText().toString().trim();
        String priceStr = binding.etPrice.getText().toString().trim();

        if (name.isEmpty() || category.isEmpty() || qr.isEmpty() || condition.isEmpty() || priceStr.isEmpty()) {
            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            price = 0.0;
        }

        String status;
        if ("Defective".equalsIgnoreCase(condition)) {
            status = "Defective";
        } else if ("On Hold".equalsIgnoreCase(condition)) {
            status = "On Hold";
        } else {
            status = "Available";
        }

        // Department is removed from constructor call (Part 1.2)
        InventoryItem item = new InventoryItem(
            isEditMode ? itemId : "",
            name,
            category,
            currentQty, // Hardcoded to 1 for individual tracking (Part 1.1)
            qr,
            status,
            condition,
            price,
            isEditMode ? getIntent().getIntExtra("ITEM_DAMAGE_COUNT", 0) : 0
        );

        if (isEditMode) {
            firebaseManager.updateItem(item, success -> {
                if (success) {
                    Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            firebaseManager.addItem(item, success -> {
                if (success) {
                    Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}

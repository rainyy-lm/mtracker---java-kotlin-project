package com.example.mtracker.activities;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.mtracker.MainActivity;
import com.example.mtracker.R;
import com.example.mtracker.adapters.TransactionAdapter;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityHistoryBinding;
import com.example.mtracker.models.Transaction;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {
    private ActivityHistoryBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private TransactionAdapter adapter;
    private String userRole;
    private String username;
    private String idNumber;
    private List<Transaction> allTransactions = new ArrayList<>();
    private String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userRole = getIntent().getStringExtra("USER_ROLE");
        username = getIntent().getStringExtra("USERNAME");
        idNumber = getIntent().getStringExtra("ADMIN_NUMBER");

        setupRecyclerView();
        setupRefreshLayout();
        setupFilters();
        setupDatePicker();
        loadHistory(false);
        setupNavigation();
        setupRoleBasedUI();
    }

    private void setupRefreshLayout() {
        binding.swipeRefresh.setColorSchemeResources(R.color.neon_blue);
        binding.swipeRefresh.setOnRefreshListener(() -> loadHistory(true));
    }

    private void setupRoleBasedUI() {
        boolean isAdmin = "Admin".equals(userRole);
        if (!isAdmin) {
            MenuItem reportsItem = binding.bottomNav.getMenu().findItem(R.id.nav_reports);
            if (reportsItem != null) reportsItem.setVisible(false);

            binding.chipGroupRoleFilter.setVisibility(View.GONE);
            binding.chipSortStudent.setVisibility(View.GONE);
            binding.tvTitle.setText(R.string.title_your_activity_logs);
            binding.tilStudentSearch.setVisibility(View.GONE);
        } else {
            binding.tvTitle.setText(R.string.title_activity_logs);
        }
    }

    private void setupDatePicker() {
        binding.etDateFilter.setOnClickListener(v -> {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    (view, year1, monthOfYear, dayOfMonth) -> {
                        Calendar selected = Calendar.getInstance();
                        selected.set(year1, monthOfYear, dayOfMonth);
                        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
                        selectedDate = sdf.format(selected.getTime());
                        binding.etDateFilter.setText(selectedDate);
                        applyFilters();
                    }, year, month, day);
            
            // Add a "Clear" button to the dialog if possible, or just handle empty text
            datePickerDialog.setButton(DatePickerDialog.BUTTON_NEUTRAL, "Clear", (dialog, which) -> {
                selectedDate = "";
                binding.etDateFilter.setText("");
                applyFilters();
            });
            
            datePickerDialog.show();
        });
    }

    private void setupFilters() {
        binding.chipGroupRoleFilter.setOnCheckedStateChangeListener((group, checkedIds) -> applyFilters());
        binding.chipGroupStatusFilter.setOnCheckedStateChangeListener((group, checkedIds) -> applyFilters());
        binding.chipGroupSort.setOnCheckedStateChangeListener((group, checkedIds) -> {
            boolean isAdmin = "Admin".equals(userRole);
            if (isAdmin && group.getCheckedChipId() == R.id.chipSortStudent) {
                binding.tilStudentSearch.setVisibility(View.VISIBLE);
            } else {
                binding.tilStudentSearch.setVisibility(View.GONE);
                binding.etStudentSearch.setText("");
            }
            applyFilters();
        });

        binding.etStudentSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                applyFilters();
            }
        });
    }

    private void applyFilters() {
        List<Transaction> filtered = new ArrayList<>();
        boolean isAdmin = "Admin".equals(userRole);
        SimpleDateFormat fullSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        SimpleDateFormat dateOnlySdf = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
        
        boolean showOnlyMine = !isAdmin || binding.chipMyActivity.isChecked();
        int checkedStatusId = binding.chipGroupStatusFilter.getCheckedChipId();
        String studentQuery = binding.etStudentSearch.getText().toString().trim().toLowerCase();

        for (Transaction t : allTransactions) {
            if (t.getStatus() != null && t.getStatus().startsWith("Returned")) continue;

            // Identity Filter
            boolean matchesIdentity = !showOnlyMine || (username != null && username.equalsIgnoreCase(t.getStudentName()));
            
            // Student ID Search (Only when Sort by Student is active and field is visible)
            if (isAdmin && binding.tilStudentSearch.getVisibility() == View.VISIBLE && !studentQuery.isEmpty()) {
                String studentId = t.getStudentId() != null ? t.getStudentId().toLowerCase() : "";
                if (!studentId.contains(studentQuery)) {
                    matchesIdentity = false;
                }
            }

            // Status Filter - Modified to exclude Overdue from Borrowed filter
            boolean matchesStatus = true;
            if (checkedStatusId == R.id.chipFilterBorrowed) {
                matchesStatus = "Borrowed".equalsIgnoreCase(t.getStatus()) && !t.isOverdue();
            } else if (checkedStatusId == R.id.chipFilterOverdue) {
                matchesStatus = t.isOverdue();
            }

            // Date Filter
            boolean matchesDate = true;
            if (!selectedDate.isEmpty()) {
                try {
                    Date tDate = fullSdf.parse(t.getDate());
                    if (tDate != null) {
                        String tDateStr = dateOnlySdf.format(tDate);
                        matchesDate = selectedDate.equals(tDateStr);
                    } else {
                        matchesDate = false;
                    }
                } catch (Exception e) {
                    matchesDate = false;
                }
            }

            if (matchesIdentity && matchesStatus && matchesDate) {
                filtered.add(t);
            }
        }

        int checkedSortId = binding.chipGroupSort.getCheckedChipId();
        if (checkedSortId == R.id.chipSortDate) {
            Collections.sort(filtered, (t1, t2) -> {
                String d1 = t1.getDate() != null ? t1.getDate() : "";
                String d2 = t2.getDate() != null ? t2.getDate() : "";
                return d2.compareTo(d1);
            });
        } else if (checkedSortId == R.id.chipSortStudent && isAdmin) {
            Collections.sort(filtered, (t1, t2) -> {
                String n1 = t1.getStudentName() != null ? t1.getStudentName() : "";
                String n2 = t2.getStudentName() != null ? t2.getStudentName() : "";
                return n1.compareToIgnoreCase(n2);
            });
        } else if (checkedSortId == R.id.chipSortItem) {
            Collections.sort(filtered, (t1, t2) -> {
                String i1 = t1.getItemName() != null ? t1.getItemName() : "";
                String i2 = t2.getItemName() != null ? t2.getItemName() : "";
                return i1.compareToIgnoreCase(i2);
            });
        } else if (checkedSortId == R.id.chipSortStatus) {
            Collections.sort(filtered, (t1, t2) -> {
                String s1 = t1.getStatus() != null ? t1.getStatus() : "";
                String s2 = t2.getStatus() != null ? t2.getStatus() : "";
                return s1.compareTo(s2);
            });
        }

        adapter.updateList(filtered);
    }

    private void setupNavigation() {
        binding.bottomNav.setSelectedItemId(R.id.nav_history);
        binding.bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.putExtra("ADMIN_NUMBER", idNumber);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_inventory) {
                Intent intent = new Intent(this, InventoryActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.putExtra("ADMIN_NUMBER", idNumber);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_history) {
                return true;
            } else if (itemId == R.id.nav_reports) {
                Intent intent = new Intent(this, ReportsActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.putExtra("ADMIN_NUMBER", idNumber);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            }
            return false;
        });
    }

    private void setupRecyclerView() {
        adapter = new TransactionAdapter(new ArrayList<>());
        binding.rvHistory.setLayoutManager(new LinearLayoutManager(this));
        binding.rvHistory.setAdapter(adapter);
    }

    private void loadHistory(boolean showSpinner) {
        if (showSpinner) {
            binding.swipeRefresh.setRefreshing(true);
        }
        firebaseManager.getAllTransactions(history -> {
            allTransactions = history;
            applyFilters();
            binding.swipeRefresh.setRefreshing(false);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory(false);
        binding.bottomNav.setSelectedItemId(R.id.nav_history);
        setupRoleBasedUI();
    }
}

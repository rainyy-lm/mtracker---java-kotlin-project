package com.example.mtracker.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.mtracker.databinding.ItemTransactionBinding;
import com.example.mtracker.models.Transaction;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    private List<Transaction> transactions;

    public TransactionAdapter(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final ItemTransactionBinding binding;
        public ViewHolder(ItemTransactionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTransactionBinding binding = ItemTransactionBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaction trans = transactions.get(position);
        holder.binding.tvTransItemName.setText(trans.getItemName());
        holder.binding.tvTransQuantity.setText("Qty: " + trans.getQuantity());
        holder.binding.tvTransStudent.setText(trans.getStudentName() + " (" + trans.getStudentId() + ")");
        holder.binding.tvTransDate.setText(trans.getDate());
        
        String status = trans.getStatus();
        boolean isOverdue = false;

        if ("Borrowed".equalsIgnoreCase(status) && trans.getDueDate() != null && !trans.getDueDate().isEmpty()) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                Date dueDate = sdf.parse(trans.getDueDate());
                if (dueDate != null && new Date().after(dueDate)) {
                    isOverdue = true;
                }
            } catch (Exception ignored) {}
        }

        if (isOverdue) {
            holder.binding.tvTransStatus.setText("OVERDUE");
            holder.binding.tvTransStatus.setTextColor(Color.RED);
        } else {
            holder.binding.tvTransStatus.setText(status);
            if ("Borrowed".equalsIgnoreCase(status)) {
                holder.binding.tvTransStatus.setTextColor(Color.parseColor("#F472B6")); // neon_pink
            } else {
                holder.binding.tvTransStatus.setTextColor(Color.parseColor("#10B981")); // success_green
            }
        }
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }

    public void updateList(List<Transaction> newList) {
        this.transactions = newList;
        notifyDataSetChanged();
    }
}

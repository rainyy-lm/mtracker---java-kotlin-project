package com.example.mtracker.activities;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.example.mtracker.MainActivity;
import com.example.mtracker.R;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityReportsBinding;
import com.example.mtracker.models.InventoryItem;
import com.example.mtracker.models.Transaction;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ReportsActivity extends AppCompatActivity {
    private ActivityReportsBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private String userRole;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityReportsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userRole = getIntent().getStringExtra("USER_ROLE");
        username = getIntent().getStringExtra("USERNAME");

        binding.btnExport.setOnClickListener(v -> {
            exportToCSV();
        });

        generateReports();
        setupNavigation();
    }

    private void setupNavigation() {
        binding.bottomNav.setSelectedItemId(R.id.nav_reports);
        binding.bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_inventory) {
                Intent intent = new Intent(this, InventoryActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_history) {
                Intent intent = new Intent(this, HistoryActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_reports) {
                return true;
            }
            return false;
        });
    }

    private void generateReports() {
        firebaseManager.getAllItems(items -> {
            firebaseManager.getAllTransactions(transactions -> {
                calculateOverdueLeaderboard(transactions);
                calculateTotalOutOfLabValue(items);
                calculateMostDamagedItems(items);
                calculateMostBorrowed(transactions);
                calculateBorrowedMonitor(transactions);
                calculateItemsOnHold(items);
            });
        });
    }

    private void calculateItemsOnHold(List<InventoryItem> items) {
        int count = 0;
        for (InventoryItem item : items) {
            if ("On Hold".equalsIgnoreCase(item.getStatus()) || "On Hold".equalsIgnoreCase(item.getCondition())) {
                count++;
            }
        }
        binding.tvItemsOnHoldCount.setText(String.valueOf(count));
    }

    private void calculateBorrowedMonitor(List<Transaction> transactions) {
        List<Transaction> borrowed = new ArrayList<>();
        for (Transaction t : transactions) {
            if ("Borrowed".equalsIgnoreCase(t.getStatus())) {
                borrowed.add(t);
            }
        }

        if (borrowed.isEmpty()) {
            binding.tvBorrowedMonitor.setText("No items currently borrowed.");
            return;
        }

        Collections.sort(borrowed, (t1, t2) -> t1.getDueDate().compareTo(t2.getDueDate()));

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date now = new Date();
        StringBuilder sb = new StringBuilder();

        for (Transaction t : borrowed) {
            try {
                Date due = sdf.parse(t.getDueDate());
                if (due != null) {
                    long diff = due.getTime() - now.getTime();
                    String timeStr;
                    if (diff < 0) {
                        timeStr = "OVERDUE";
                    } else {
                        long hours = diff / (60 * 60 * 1000);
                        long minutes = (diff / (60 * 1000)) % 60;
                        timeStr = String.format(Locale.getDefault(), "%dh %dm left", hours, minutes);
                    }
                    sb.append("• ").append(t.getItemName()).append(" (").append(t.getStudentName()).append(")\n")
                      .append("  Time: ").append(timeStr).append("\n\n");
                }
            } catch (Exception ignored) {}
        }
        binding.tvBorrowedMonitor.setText(sb.toString().trim());
    }

    private void calculateOverdueLeaderboard(List<Transaction> transactions) {
        List<Transaction> overdue = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date now = new Date();

        for (Transaction t : transactions) {
            if ("Borrowed".equalsIgnoreCase(t.getStatus()) && t.getDueDate() != null && !t.getDueDate().isEmpty()) {
                try {
                    Date due = sdf.parse(t.getDueDate());
                    if (due != null && now.after(due)) {
                        overdue.add(t);
                    }
                } catch (Exception ignored) {}
            }
        }

        Collections.sort(overdue, (t1, t2) -> t1.getDueDate().compareTo(t2.getDueDate()));

        if (overdue.isEmpty()) {
            binding.tvOverdueLeaderboard.setText("No overdue items.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(overdue.size(), 5); i++) {
                Transaction t = overdue.get(i);
                sb.append(i + 1).append(". ").append(t.getStudentName())
                  .append(" - ").append(t.getItemName())
                  .append(" (Due: ").append(t.getDueDate().substring(0, 10)).append(")\n");
            }
            binding.tvOverdueLeaderboard.setText(sb.toString().trim());
        }
    }

    private void calculateTotalOutOfLabValue(List<InventoryItem> items) {
        double totalValue = 0;
        int count = 0;
        for (InventoryItem item : items) {
            if ("Borrowed".equalsIgnoreCase(item.getStatus())) {
                totalValue += item.getPrice();
                count++;
            }
        }
        binding.tvTotalAssetValue.setText(String.format(Locale.getDefault(), "₱%.2f", totalValue));
        binding.tvCheckedOutCount.setText(count + " items currently borrowed");
    }

    private void calculateMostDamagedItems(List<InventoryItem> items) {
        List<InventoryItem> damaged = new ArrayList<>(items);
        Collections.sort(damaged, (i1, i2) -> Integer.compare(i2.getDamageCount(), i1.getDamageCount()));

        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (InventoryItem item : damaged) {
            if (item.getDamageCount() > 0) {
                sb.append(item.getItemName()).append(": ").append(item.getDamageCount()).append(" incidents\n");
                count++;
                if (count >= 5) break;
            }
        }

        if (sb.length() == 0) {
            binding.tvMostDamagedList.setText("No damage records found.");
        } else {
            binding.tvMostDamagedList.setText(sb.toString().trim());
        }
    }

    private void calculateMostBorrowed(List<Transaction> transactions) {
        Map<String, Integer> borrowedMap = new HashMap<>();
        for (Transaction t : transactions) {
            if ("Borrowed".equalsIgnoreCase(t.getStatus())) {
                borrowedMap.put(t.getItemName(), borrowedMap.getOrDefault(t.getItemName(), 0) + 1);
            }
        }

        if (borrowedMap.isEmpty()) {
            binding.tvMostBorrowedList.setText("No borrowing data.");
            return;
        }

        List<Map.Entry<String, Integer>> list = new ArrayList<>(borrowedMap.entrySet());
        Collections.sort(list, (e1, e2) -> e2.getValue().compareTo(e1.getValue()));

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(list.size(), 3); i++) {
            sb.append(list.get(i).getKey()).append(" (").append(list.get(i).getValue()).append(" times)\n");
        }
        binding.tvMostBorrowedList.setText(sb.toString().trim());
    }

    private void exportToCSV() {
        firebaseManager.getAllTransactions(transactions -> {
            if (transactions.isEmpty()) {
                Toast.makeText(this, "No transactions to export", Toast.LENGTH_SHORT).show();
                return;
            }

            String filename = "mtracker_report_" + System.currentTimeMillis() + ".csv";
            StringBuilder csvData = new StringBuilder("ID,Student Name,Item,Quantity,Date,Status\n");
            for (Transaction it : transactions) {
                if (it.getStatus() != null && it.getStatus().startsWith("Returned")) continue;

                csvData.append(it.getId()).append(",")
                        .append(it.getStudentName()).append(",")
                        .append(it.getItemName()).append(",")
                        .append(it.getQuantity()).append(",")
                        .append(it.getDate()).append(",")
                        .append(it.getStatus()).append("\n");
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                    contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                    contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues);
                    if (uri != null) {
                        OutputStream outputStream = getContentResolver().openOutputStream(uri);
                        if (outputStream != null) {
                            outputStream.write(csvData.toString().getBytes());
                            outputStream.close();
                            Toast.makeText(this, "Report saved to Downloads folder", Toast.LENGTH_LONG).show();
                            shareCSVUri(uri);
                        }
                    }
                } else {
                    File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    File file = new File(path, filename);
                    FileOutputStream out = new FileOutputStream(file);
                    out.write(csvData.toString().getBytes());
                    out.close();
                    Toast.makeText(this, "Report saved to Downloads folder", Toast.LENGTH_LONG).show();
                    shareCSVFile(file);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void shareCSVUri(Uri uri) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_SUBJECT, "M-Tracker Report");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        startActivity(Intent.createChooser(intent, "Share Report via"));
    }

    private void shareCSVFile(File file) {
        Uri path = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        shareCSVUri(path);
    }

    @Override
    protected void onResume() {
        super.onResume();
        binding.bottomNav.setSelectedItemId(R.id.nav_reports);
    }
}

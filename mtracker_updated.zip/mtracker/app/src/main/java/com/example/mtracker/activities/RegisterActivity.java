package com.example.mtracker.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityRegisterBinding;
import com.example.mtracker.models.User;

public class RegisterActivity extends AppCompatActivity {
    private ActivityRegisterBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private boolean isInternalAdminCreate = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        isInternalAdminCreate = getIntent().getBooleanExtra("IS_INTERNAL_ADMIN_CREATE", false);

        if (isInternalAdminCreate) {
            binding.tvLogin.setVisibility(View.GONE);
            binding.tvTitle.setText("Admin Registration");
        }

        binding.btnRegister.setEnabled(false);
        checkAdminRequirement();

        binding.btnBack.setOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        binding.btnRegister.setOnClickListener(v -> handleRegistration());

        binding.tvLogin.setOnClickListener(v -> finish());
    }

    private void checkAdminRequirement() {
        firebaseManager.isAdminExists(exists -> {
            binding.btnRegister.setEnabled(true);

            if (isInternalAdminCreate) {
                binding.tvTitle.setText("Create Admin Account");
                binding.rbAdmin.setChecked(true);
                binding.tilStudentNumber.setHint("Admin Number");
            } else if (exists) {
                binding.tvTitle.setText("Student Registration");
                binding.rbStudent.setChecked(true);
                binding.tilStudentNumber.setHint("Student Number (e.g. 2024-0001)");
            } else {
                binding.tvTitle.setText("Admin Setup");
                binding.rbAdmin.setChecked(true);
                binding.tilStudentNumber.setHint("Admin Number");
                Toast.makeText(this, "First user will be registered as Admin", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void handleRegistration() {
        String username = binding.etUsername.getText().toString().trim();
        String password = binding.etPassword.getText().toString().trim();
        String idNumber = binding.etStudentNumber.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty() || idNumber.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        firebaseManager.isAdminExists(exists -> {
            String role;
            if (isInternalAdminCreate || !exists) {
                role = "Admin";
            } else {
                role = "Student";
            }

            checkUsernameAndPerform(username, password, role, idNumber);
        });
    }

    private void checkUsernameAndPerform(String username, String password, String role, String idNum) {
        firebaseManager.isUsernameExists(username, usernameExists -> {
            if (usernameExists) {
                Toast.makeText(this, "Username already taken", Toast.LENGTH_SHORT).show();
            } else {
                performRegistration(username, password, role, idNum);
            }
        });
    }

    private void performRegistration(String username, String password, String role, String idNumber) {
        User newUser = new User("", username, password, role, idNumber);
        firebaseManager.addUser(newUser, success -> {
            if (success) {
                String msg = isInternalAdminCreate ? "Admin created successfully" : "Registration Successful";
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Operation Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

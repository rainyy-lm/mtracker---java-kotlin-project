package com.example.mtracker.models;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class InventoryItem {
    private String id;
    private String itemName;
    private String category; // Consumable, Equipment, Part, Board
    private int quantity;
    private String qrCode;
    private String status; // "Available", "Borrowed", "Out of Stock", "Defective", "On Hold"
    private String condition; // "New", "Good", "Fair", "Poor"
    private String borrowerName;
    private String borrowerId;
    private String dueDate;
    private double price;
    private int damageCount;

    public InventoryItem() {
        this.id = "";
        this.itemName = "";
        this.category = "";
        this.quantity = 1;
        this.qrCode = "";
        this.status = "";
        this.condition = "";
        this.borrowerName = "";
        this.borrowerId = "";
        this.dueDate = "";
        this.price = 0.0;
        this.damageCount = 0;
    }

    public InventoryItem(String id, String itemName, String category, int quantity, String qrCode, String status, String condition, double price, int damageCount) {
        this.id = id;
        this.itemName = itemName;
        this.category = category;
        this.quantity = quantity;
        this.qrCode = qrCode;
        this.status = status;
        this.condition = condition;
        this.price = price;
        this.damageCount = damageCount;
        this.borrowerName = "";
        this.borrowerId = "";
        this.dueDate = "";
    }

    // Constructor for legacy compatibility if needed
    public InventoryItem(String id, String itemName, String category, int quantity, String qrCode, String status, String condition, double price) {
        this(id, itemName, category, quantity, qrCode, status, condition, price, 0);
    }

    public boolean isOverdue() {
        if (!"Borrowed".equalsIgnoreCase(status) || dueDate == null || dueDate.isEmpty()) {
            return false;
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date due = sdf.parse(dueDate);
            return due != null && new Date().after(due);
        } catch (Exception e) {
            return false;
        }
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCondition() { return condition; }
    public void setCondition(String condition) { this.condition = condition; }

    public String getBorrowerName() { return borrowerName; }
    public void setBorrowerName(String borrowerName) { this.borrowerName = borrowerName; }

    public String getBorrowerId() { return borrowerId; }
    public void setBorrowerId(String borrowerId) { this.borrowerId = borrowerId; }

    public String getDueDate() { return dueDate; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getDamageCount() { return damageCount; }
    public void setDamageCount(int damageCount) { this.damageCount = damageCount; }
}

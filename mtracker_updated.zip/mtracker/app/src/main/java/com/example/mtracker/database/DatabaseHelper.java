package com.example.mtracker.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.mtracker.models.InventoryItem;
import com.example.mtracker.models.Transaction;
import com.example.mtracker.models.User;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MTracker.db";
    private static final int DATABASE_VERSION = 3;

    // Users Table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";
    public static final String COL_ROLE = "role";

    // Inventory Table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_CATEGORY = "category";
    public static final String COL_QTY = "quantity";
    public static final String COL_QR = "qr_code";
    public static final String COL_STATUS = "status";
    public static final String COL_CONDITION = "condition";
    public static final String COL_PRICE = "price";
    public static final String COL_DAMAGE_COUNT = "damage_count";

    // Transactions Table
    public static final String TABLE_TRANSACTIONS = "transactions";
    public static final String COL_TRANS_ID = "id";
    public static final String COL_STU_NAME = "student_name";
    public static final String COL_STU_ID = "student_id";
    public static final String COL_TRANS_ITEM = "item_name";
    public static final String COL_TRANS_QTY = "quantity";
    public static final String COL_DATE = "date";
    public static final String COL_TRANS_STATUS = "status";
    public static final String COL_DUE_DATE = "due_date";
    public static final String COL_TRANS_QR = "qr_code";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_USERNAME + " TEXT," +
                COL_PASSWORD + " TEXT," +
                COL_ROLE + " TEXT)";
        
        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_ITEM_NAME + " TEXT," +
                COL_CATEGORY + " TEXT," +
                COL_QTY + " INTEGER," +
                COL_QR + " TEXT," +
                COL_STATUS + " TEXT," +
                COL_CONDITION + " TEXT," +
                COL_PRICE + " REAL," +
                COL_DAMAGE_COUNT + " INTEGER DEFAULT 0)";

        String createTransactionsTable = "CREATE TABLE " + TABLE_TRANSACTIONS + " (" +
                COL_TRANS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COL_STU_NAME + " TEXT," +
                COL_STU_ID + " TEXT," +
                COL_TRANS_ITEM + " TEXT," +
                COL_TRANS_QR + " TEXT," +
                COL_TRANS_QTY + " INTEGER," +
                COL_DATE + " TEXT," +
                COL_TRANS_STATUS + " TEXT," +
                COL_DUE_DATE + " TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
        db.execSQL(createTransactionsTable);

        seedData(db);
    }

    private void seedData(SQLiteDatabase db) {
        // Seed Admin Account
        ContentValues admin = new ContentValues();
        admin.put(COL_USERNAME, "admin");
        admin.put(COL_PASSWORD, "admin123");
        admin.put(COL_ROLE, "Admin");
        db.insert(TABLE_USERS, null, admin);

        // Part 2.2: Mock Data Seeding
        // Consumable items
        insertItem(db, "Resistors (10k)", "Consumable", 5, "RES-10K", "Available", "Good", 1.50, 0);
        
        // High price items
        insertItem(db, "Arduino Uno", "Board", 1, "ARD-001", "Available", "Good", 450.00, 0);
        insertItem(db, "Oscilloscope", "Equipment", 1, "OSC-001", "Available", "Good", 15000.00, 2);

        // Seed an active transaction with a due date in the past for instant overdue status
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1); // Yesterday
        String yesterday = sdf.format(cal.getTime());
        
        cal.add(Calendar.DAY_OF_YEAR, -5); // 6 days ago
        String borrowedDate = sdf.format(cal.getTime());

        ContentValues trans = new ContentValues();
        trans.put(COL_STU_NAME, "John Doe");
        trans.put(COL_STU_ID, "2021-0001");
        trans.put(COL_TRANS_ITEM, "Arduino Uno");
        trans.put(COL_TRANS_QR, "ARD-001");
        trans.put(COL_TRANS_QTY, 1);
        trans.put(COL_DATE, borrowedDate);
        trans.put(COL_TRANS_STATUS, "Borrowed");
        trans.put(COL_DUE_DATE, yesterday); // Forced overdue
        db.insert(TABLE_TRANSACTIONS, null, trans);

        // Mark item as borrowed in inventory
        db.execSQL("UPDATE " + TABLE_INVENTORY + " SET " + COL_STATUS + "='Borrowed' WHERE " + COL_QR + "='ARD-001'");
    }

    private void insertItem(SQLiteDatabase db, String name, String cat, int qty, String qr, String status, String cond, double price, int damage) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_CATEGORY, cat);
        values.put(COL_QTY, qty);
        values.put(COL_QR, qr);
        values.put(COL_STATUS, status);
        values.put(COL_CONDITION, cond);
        values.put(COL_PRICE, price);
        values.put(COL_DAMAGE_COUNT, damage);
        db.insert(TABLE_INVENTORY, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        onCreate(db);
    }

    // --- User Operations ---
    public long addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, user.getUsername());
        values.put(COL_PASSWORD, user.getPassword());
        values.put(COL_ROLE, user.getRole());
        return db.insert(TABLE_USERS, null, values);
    }

    public User checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?", new String[]{username, password});
        if (cursor.moveToFirst()) {
            User user = new User(
                String.valueOf(cursor.getInt(0)),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3)
            );
            cursor.close();
            return user;
        } else {
            cursor.close();
            return null;
        }
    }

    // --- Inventory Operations ---
    public long addItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, item.getItemName());
        values.put(COL_CATEGORY, item.getCategory());
        values.put(COL_QTY, item.getQuantity());
        values.put(COL_QR, item.getQrCode());
        values.put(COL_STATUS, item.getStatus());
        values.put(COL_CONDITION, item.getCondition());
        values.put(COL_PRICE, item.getPrice());
        values.put(COL_DAMAGE_COUNT, item.getDamageCount());
        return db.insert(TABLE_INVENTORY, null, values);
    }

    public int updateItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, item.getItemName());
        values.put(COL_CATEGORY, item.getCategory());
        values.put(COL_QTY, item.getQuantity());
        values.put(COL_QR, item.getQrCode());
        values.put(COL_STATUS, item.getStatus());
        values.put(COL_CONDITION, item.getCondition());
        values.put(COL_PRICE, item.getPrice());
        values.put(COL_DAMAGE_COUNT, item.getDamageCount());
        return db.update(TABLE_INVENTORY, values, COL_ITEM_ID + "=?", new String[]{item.getId()});
    }

    public List<InventoryItem> getAllItems() {
        List<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
        if (cursor.moveToFirst()) {
            do {
                list.add(new InventoryItem(
                    String.valueOf(cursor.getInt(0)),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getInt(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6),
                    cursor.getDouble(7),
                    cursor.getInt(8)
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }
    
    public void updateItemQuantity(int itemId, int newQty) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_QTY, newQty);
        values.put(COL_STATUS, newQty > 0 ? "Available" : "Out of Stock");
        db.update(TABLE_INVENTORY, values, COL_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
    }

    public InventoryItem getItemByQR(String qr) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_INVENTORY + " WHERE " + COL_QR + "=?", new String[]{qr});
        if (cursor.moveToFirst()) {
            InventoryItem item = new InventoryItem(
                String.valueOf(cursor.getInt(0)),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getInt(3),
                cursor.getString(4),
                cursor.getString(5),
                cursor.getString(6),
                cursor.getDouble(7),
                cursor.getInt(8)
            );
            cursor.close();
            return item;
        } else {
            cursor.close();
            return null;
        }
    }

    // --- Transaction Operations ---
    public long addTransaction(Transaction transaction) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_STU_NAME, transaction.getStudentName());
        values.put(COL_STU_ID, transaction.getStudentId());
        values.put(COL_TRANS_ITEM, transaction.getItemName());
        values.put(COL_TRANS_QR, transaction.getQrCode());
        values.put(COL_TRANS_QTY, transaction.getQuantity());
        values.put(COL_DATE, transaction.getDate());
        values.put(COL_TRANS_STATUS, transaction.getStatus());
        values.put(COL_DUE_DATE, transaction.getDueDate());
        return db.insert(TABLE_TRANSACTIONS, null, values);
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_TRANSACTIONS + " ORDER BY " + COL_TRANS_ID + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                Transaction t = new Transaction();
                t.setId(String.valueOf(cursor.getInt(0)));
                t.setStudentName(cursor.getString(1));
                t.setStudentId(cursor.getString(2));
                t.setItemName(cursor.getString(3));
                t.setQrCode(cursor.getString(4));
                t.setQuantity(cursor.getInt(5));
                t.setDate(cursor.getString(6));
                t.setStatus(cursor.getString(7));
                t.setDueDate(cursor.getString(8));
                list.add(t);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public boolean isItemBorrowedByUser(String itemName, String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT status FROM " + TABLE_TRANSACTIONS + " WHERE " + COL_TRANS_ITEM + "=? AND " + COL_STU_NAME + "=? ORDER BY " + COL_TRANS_ID + " DESC LIMIT 1",
            new String[]{itemName, username}
        );
        boolean isBorrowed = false;
        if (cursor.moveToFirst()) {
            isBorrowed = "Borrowed".equals(cursor.getString(0));
        }
        cursor.close();
        return isBorrowed;
    }

    public int getOverdueCount() {
        List<Transaction> transactions = getAllTransactions();
        int count = 0;
        for (Transaction t : transactions) {
            if (t.isOverdue()) {
                count++;
            }
        }
        return count;
    }
}

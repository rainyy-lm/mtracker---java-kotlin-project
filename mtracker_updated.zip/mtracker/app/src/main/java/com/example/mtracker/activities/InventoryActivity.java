package com.example.mtracker.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.mtracker.MainActivity;
import com.example.mtracker.R;
import com.example.mtracker.adapters.InventoryAdapter;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityInventoryBinding;
import com.example.mtracker.models.InventoryItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    private ActivityInventoryBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private InventoryAdapter adapter;
    private List<InventoryItem> allItems = new ArrayList<>();
    private boolean isAdmin = false;
    private String userRole;
    private String username;
    private String idNumber;
    private String currentSort = "Name"; // Default sort

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInventoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userRole = getIntent().getStringExtra("USER_ROLE");
        username = getIntent().getStringExtra("USERNAME");
        idNumber = getIntent().getStringExtra("ADMIN_NUMBER");
        isAdmin = "Admin".equals(userRole);

        setupRecyclerView();
        setupFilters();
        setupNavigation();
        setupRoleBasedUI();
        setupRefreshLayout();
        setupSort();

        loadData(false);
    }

    private void setupSort() {
        binding.btnSort.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this, v);
            popup.getMenu().add("Sort by Name");
            popup.getMenu().add("Sort by Item ID");
            
            popup.setOnMenuItemClickListener(item -> {
                if (item.getTitle().equals("Sort by Name")) {
                    currentSort = "Name";
                } else if (item.getTitle().equals("Sort by Item ID")) {
                    currentSort = "ID";
                }
                filterItems();
                return true;
            });
            popup.show();
        });
    }

    private void setupRefreshLayout() {
        binding.swipeRefresh.setColorSchemeResources(R.color.neon_blue);
        binding.swipeRefresh.setOnRefreshListener(() -> loadData(true));
    }

    private void setupRoleBasedUI() {
        if (isAdmin) {
            binding.fabAddItem.setVisibility(View.VISIBLE);
            binding.fabAddItem.setOnClickListener(v -> {
                Intent intent = new Intent(this, AddItemActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                startActivity(intent);
            });
        } else {
            binding.fabAddItem.setVisibility(View.GONE);
            MenuItem reportsItem = binding.bottomNav.getMenu().findItem(R.id.nav_reports);
            if (reportsItem != null) reportsItem.setVisible(false);
        }
    }

    private void setupNavigation() {
        binding.bottomNav.setSelectedItemId(R.id.nav_inventory);
        binding.bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.putExtra("ADMIN_NUMBER", idNumber);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_inventory) {
                return true;
            } else if (itemId == R.id.nav_history) {
                Intent intent = new Intent(this, HistoryActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.putExtra("ADMIN_NUMBER", idNumber);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            } else if (itemId == R.id.nav_reports) {
                Intent intent = new Intent(this, ReportsActivity.class);
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.putExtra("ADMIN_NUMBER", idNumber);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            }
            return false;
        });
    }

    private void setupRecyclerView() {
        adapter = new InventoryAdapter(
            new ArrayList<>(),
            isAdmin,
            idNumber,
            new InventoryAdapter.OnItemClickListener() {
                @Override
                public void onEditClick(InventoryItem item) {
                    if ("Borrowed".equalsIgnoreCase(item.getStatus())) {
                        Toast.makeText(InventoryActivity.this, "This Item is currently borrowed!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
                    intent.putExtra("IS_EDIT", true);
                    intent.putExtra("ITEM_ID", item.getId());
                    intent.putExtra("ITEM_NAME", item.getItemName());
                    intent.putExtra("ITEM_CATEGORY", item.getCategory());
                    intent.putExtra("ITEM_QR", item.getQrCode());
                    intent.putExtra("ITEM_CONDITION", item.getCondition());
                    intent.putExtra("ITEM_PRICE", item.getPrice());
                    intent.putExtra("USER_ROLE", userRole);
                    startActivity(intent);
                }

                @Override
                public void onDeleteClick(InventoryItem item) {
                    if ("Borrowed".equalsIgnoreCase(item.getStatus())) {
                        Toast.makeText(InventoryActivity.this, "This Item is currently borrowed!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    showDeleteConfirmation(item);
                }
            }
        );
        binding.rvInventory.setLayoutManager(new LinearLayoutManager(this));
        binding.rvInventory.setAdapter(adapter);
    }

    private void showDeleteConfirmation(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete '" + item.getItemName() + "'?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    firebaseManager.deleteItem(item.getId(), success -> {
                        if (success) {
                            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                            loadData(false);
                        } else {
                            Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setupFilters() {
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                filterItems();
            }
        });

        binding.chipGroupCategory.setOnCheckedStateChangeListener((group, checkedIds) -> {
            filterItems();
        });
    }

    private void loadData(boolean showSpinner) {
        if (showSpinner) {
            binding.swipeRefresh.setRefreshing(true);
        }
        firebaseManager.getAllItems(items -> {
            allItems = items;
            filterItems();
            binding.swipeRefresh.setRefreshing(false);
        });
    }

    private void filterItems() {
        String query = binding.etSearch.getText().toString().toLowerCase();
        int checkedId = binding.chipGroupCategory.getCheckedChipId();

        List<InventoryItem> filtered = new ArrayList<>();
        for (InventoryItem item : allItems) {
            boolean matchesQuery = item.getItemName().toLowerCase().contains(query);
            
            boolean matchesFilter = false;
            String itemCategory = item.getCategory() != null ? item.getCategory().toLowerCase() : "";

            if (checkedId == R.id.chipAll || checkedId == View.NO_ID) {
                matchesFilter = true;
            } else if (checkedId == R.id.chipConsumable) {
                matchesFilter = itemCategory.contains("consumable");
            } else if (checkedId == R.id.chipEquipment) {
                matchesFilter = itemCategory.contains("equipment");
            } else if (checkedId == R.id.chipPart) {
                matchesFilter = itemCategory.contains("part");
            } else if (checkedId == R.id.chipBoard) {
                matchesFilter = itemCategory.contains("board");
            }

            if (matchesQuery && matchesFilter) {
                filtered.add(item);
            }
        }

        // Apply Sorting
        if ("ID".equals(currentSort)) {
            Collections.sort(filtered, (o1, o2) -> {
                String id1 = o1.getQrCode() != null ? o1.getQrCode() : "";
                String id2 = o2.getQrCode() != null ? o2.getQrCode() : "";
                return id1.compareToIgnoreCase(id2);
            });
        } else {
            Collections.sort(filtered, (o1, o2) -> {
                String name1 = o1.getItemName() != null ? o1.getItemName() : "";
                String name2 = o2.getItemName() != null ? o2.getItemName() : "";
                return name1.compareToIgnoreCase(name2);
            });
        }

        adapter.updateList(filtered);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData(false);
        binding.bottomNav.setSelectedItemId(R.id.nav_inventory);
        setupRoleBasedUI();
    }
}

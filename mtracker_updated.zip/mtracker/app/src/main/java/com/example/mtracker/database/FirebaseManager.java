package com.example.mtracker.database;

import com.example.mtracker.models.InventoryItem;
import com.example.mtracker.models.Transaction;
import com.example.mtracker.models.User;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirebaseManager {
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();
    private final CollectionReference usersCollection = db.collection("users");
    private final CollectionReference inventoryCollection = db.collection("inventory");
    private final CollectionReference transactionsCollection = db.collection("transactions");
    private final CollectionReference requestsCollection = db.collection("borrow_requests");

    public interface OnCompleteListener {
        void onComplete(boolean success);
    }

    public interface OnResultListener<T> {
        void onResult(T result);
    }

    public void checkUser(String username, String password, OnResultListener<User> onResult) {
        usersCollection.whereEqualTo("username", username)
                .whereEqualTo("password", password)
                .get()
                .addOnSuccessListener(documents -> {
                    if (!documents.isEmpty()) {
                        onResult.onResult(documents.getDocuments().get(0).toObject(User.class));
                    } else {
                        onResult.onResult(null);
                    }
                })
                .addOnFailureListener(e -> onResult.onResult(null));
    }

    public void getAllItems(OnResultListener<List<InventoryItem>> onResult) {
        inventoryCollection.get().addOnSuccessListener(documents -> {
            onResult.onResult(documents.toObjects(InventoryItem.class));
        }).addOnFailureListener(e -> onResult.onResult(new ArrayList<>()));
    }

    public void getItemByQR(String qr, OnResultListener<InventoryItem> onResult) {
        inventoryCollection.whereEqualTo("qrCode", qr).get().addOnSuccessListener(documents -> {
            if (!documents.isEmpty()) {
                onResult.onResult(documents.getDocuments().get(0).toObject(InventoryItem.class));
            } else {
                onResult.onResult(null);
            }
        }).addOnFailureListener(e -> onResult.onResult(null));
    }

    public void updateItem(InventoryItem item, OnCompleteListener onComplete) {
        inventoryCollection.document(item.getId()).set(item)
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    public void addItem(InventoryItem item, OnCompleteListener onComplete) {
        DocumentReference itemRef = inventoryCollection.document();
        item.setId(itemRef.getId());
        itemRef.set(item)
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    public void deleteItem(String itemId, OnCompleteListener onComplete) {
        inventoryCollection.document(itemId).delete()
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    public void createBorrowRequest(String studentNumber, List<InventoryItem> items, OnResultListener<String> onResult) {
        DocumentReference ref = requestsCollection.document();
        Map<String, Object> request = new HashMap<>();
        request.put("id", ref.getId());
        request.put("studentNumber", studentNumber);
        request.put("status", "Pending");
        request.put("timestamp", System.currentTimeMillis());
        
        List<Map<String, Object>> itemData = new ArrayList<>();
        for (InventoryItem item : items) {
            Map<String, Object> m = new HashMap<>();
            m.put("id", item.getId());
            m.put("name", item.getItemName());
            m.put("qrCode", item.getQrCode());
            m.put("quantity", item.getQuantity()); 
            itemData.add(m);
        }
        request.put("items", itemData);

        ref.set(request)
                .addOnSuccessListener(aVoid -> onResult.onResult(ref.getId()))
                .addOnFailureListener(e -> onResult.onResult(null));
    }

    public ListenerRegistration listenForRequests(String studentNumber, OnResultListener<Map<String, Object>> onResult) {
        return requestsCollection.whereEqualTo("studentNumber", studentNumber)
                .whereEqualTo("status", "Pending")
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null || value.isEmpty()) return;
                    onResult.onResult(value.getDocuments().get(0).getData());
                });
    }

    public void updateRequestStatus(String requestId, String status, OnCompleteListener onComplete) {
        requestsCollection.document(requestId).update("status", status)
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    public void addTransaction(Transaction transaction, OnCompleteListener onComplete) {
        DocumentReference transRef = transactionsCollection.document();
        if (transaction.getId() == null || transaction.getId().isEmpty()) {
            transaction.setId(transRef.getId());
        }
        transactionsCollection.document(transaction.getId()).set(transaction)
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    public void getAllTransactions(OnResultListener<List<Transaction>> onResult) {
        transactionsCollection.orderBy("date", Query.Direction.DESCENDING).get().addOnSuccessListener(documents -> {
            onResult.onResult(documents.toObjects(Transaction.class));
        }).addOnFailureListener(e -> onResult.onResult(new ArrayList<>()));
    }

    public void getActiveTransactionsForItem(String qrCode, OnResultListener<List<Transaction>> onResult) {
        transactionsCollection.whereEqualTo("qrCode", qrCode)
                .whereIn("status", Arrays.asList("Borrowed", "Overdue"))
                .get()
                .addOnSuccessListener(documents -> {
                    onResult.onResult(documents.toObjects(Transaction.class));
                })
                .addOnFailureListener(e -> onResult.onResult(new ArrayList<>()));
    }

    public void getActiveTransactionForItem(String qrCode, OnResultListener<Transaction> onResult) {
        transactionsCollection.whereEqualTo("qrCode", qrCode)
                .whereIn("status", Arrays.asList("Borrowed", "Overdue"))
                .limit(1)
                .get()
                .addOnSuccessListener(documents -> {
                    if (!documents.isEmpty()) {
                        onResult.onResult(documents.getDocuments().get(0).toObject(Transaction.class));
                    } else {
                        onResult.onResult(null);
                    }
                })
                .addOnFailureListener(e -> onResult.onResult(null));
    }

    /**
     * Updated Borrow Logic: Sets quantity to 0 when borrowed.
     */
    public void borrowInventory(String itemId, int amount, String borrowerName, String borrowerId, String dueDate, OnCompleteListener onComplete) {
        DocumentReference itemRef = inventoryCollection.document(itemId);
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "Borrowed");
        updates.put("quantity", 0); // Logic: 1 -> 0
        updates.put("borrowerName", borrowerName);
        updates.put("borrowerId", borrowerId);
        updates.put("dueDate", dueDate);

        itemRef.update(updates)
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    /**
     * Updated Return Logic: Resets quantity to 1 when returned.
     */
    public void returnInventory(String itemId, int amount, String condition, OnCompleteListener onComplete) {
        DocumentReference itemRef = inventoryCollection.document(itemId);
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "Defective".equalsIgnoreCase(condition) ? "Defective" : "Available");
        updates.put("condition", condition);
        updates.put("quantity", 1); // Logic: 0 -> 1
        updates.put("borrowerName", "");
        updates.put("borrowerId", "");
        updates.put("dueDate", "");

        itemRef.update(updates)
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    // Deprecated but kept for compatibility if needed elsewhere
    public void updateItemBorrower(String itemId, String borrowerName, String borrowerId, String dueDate, OnCompleteListener onComplete) {
        borrowInventory(itemId, 1, borrowerName, borrowerId, dueDate, onComplete);
    }

    public void updateItemStatus(String itemId, String status, String condition, OnCompleteListener onComplete) {
        returnInventory(itemId, 1, condition, onComplete);
    }

    public void getAllStudents(OnResultListener<List<User>> onResult) {
        usersCollection.whereEqualTo("role", "Student").get().addOnSuccessListener(documents -> {
            onResult.onResult(documents.toObjects(User.class));
        }).addOnFailureListener(e -> onResult.onResult(new ArrayList<>()));
    }

    public void deleteUser(String userId, OnCompleteListener onComplete) {
        usersCollection.document(userId).delete()
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }

    public void deleteAllStudents(OnCompleteListener onComplete) {
        usersCollection.whereEqualTo("role", "Student").get().addOnSuccessListener(documents -> {
            WriteBatch batch = db.batch();
            for (DocumentSnapshot doc : documents) {
                batch.delete(doc.getReference());
            }
            batch.commit()
                    .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                    .addOnFailureListener(e -> onComplete.onComplete(false));
        }).addOnFailureListener(e -> onComplete.onComplete(false));
    }

    public void isAdminExists(OnResultListener<Boolean> onResult) {
        usersCollection.whereEqualTo("role", "Admin").limit(1).get().addOnSuccessListener(documents -> {
            onResult.onResult(!documents.isEmpty());
        }).addOnFailureListener(e -> onResult.onResult(false));
    }

    public void isUsernameExists(String username, OnResultListener<Boolean> onResult) {
        usersCollection.whereEqualTo("username", username).limit(1).get().addOnSuccessListener(documents -> {
            onResult.onResult(!documents.isEmpty());
        }).addOnFailureListener(e -> onResult.onResult(false));
    }

    public void addUser(User user, OnCompleteListener onComplete) {
        DocumentReference userRef = usersCollection.document();
        user.setId(userRef.getId());
        userRef.set(user)
                .addOnSuccessListener(aVoid -> onComplete.onComplete(true))
                .addOnFailureListener(e -> onComplete.onComplete(false));
    }
}

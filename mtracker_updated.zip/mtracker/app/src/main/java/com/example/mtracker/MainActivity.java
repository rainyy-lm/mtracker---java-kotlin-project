package com.example.mtracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.mtracker.activities.HistoryActivity;
import com.example.mtracker.activities.InventoryActivity;
import com.example.mtracker.activities.LoginActivity;
import com.example.mtracker.activities.ReportsActivity;
import com.example.mtracker.activities.ScanActivity;
import com.example.mtracker.activities.SettingsActivity;
import com.example.mtracker.adapters.TransactionAdapter;
import com.example.mtracker.database.FirebaseManager;
import com.example.mtracker.databinding.ActivityMainBinding;
import com.example.mtracker.models.Transaction;
import com.google.firebase.firestore.ListenerRegistration;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private final FirebaseManager firebaseManager = new FirebaseManager();
    private String userRole;
    private String username;
    private String idNumber;
    private boolean isShowingOverallLogs = true;
    private List<Transaction> allTransactions = new ArrayList<>();
    private ListenerRegistration requestListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        userRole = getIntent().getStringExtra("USER_ROLE");
        username = getIntent().getStringExtra("USERNAME");
        idNumber = getIntent().getStringExtra("ADMIN_NUMBER");

        if (userRole == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupDashboard(false);
        setupListeners();
        setupRoleBasedUI();
        setupRefreshLayout();
        
        if ("Student".equals(userRole) && idNumber != null) {
            listenForBorrowRequests();
        }
    }

    private void listenForBorrowRequests() {
        requestListener = firebaseManager.listenForRequests(idNumber, requestData -> {
            if (requestData == null) return;
            
            String requestId = (String) requestData.get("id");
            List<Map<String, Object>> items = (List<Map<String, Object>>) requestData.get("items");
            
            StringBuilder itemNames = new StringBuilder();
            for (Map<String, Object> item : items) {
                itemNames.append("- ").append(item.get("name")).append("\n");
            }

            new AlertDialog.Builder(this)
                    .setTitle("Borrow Request Notification")
                    .setMessage("An admin is requesting you to accept the following items:\n\n" + itemNames.toString() + "\nDo you accept?")
                    .setPositiveButton("Accept", (dialog, which) -> handleRequest(requestId, items, "Accepted"))
                    .setNegativeButton("Cancel", (dialog, which) -> handleRequest(requestId, items, "Cancelled"))
                    .setCancelable(false)
                    .show();
        });
    }

    private void handleRequest(String requestId, List<Map<String, Object>> items, String status) {
        firebaseManager.updateRequestStatus(requestId, status, success -> {
            if (success && "Accepted".equals(status)) {
                processAcceptedItems(items);
            }
        });
    }

    private void processAcceptedItems(List<Map<String, Object>> items) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date now = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        cal.add(Calendar.DAY_OF_YEAR, 7); // Default 7 days
        String dueDate = sdf.format(cal.getTime());

        for (Map<String, Object> itemData : items) {
            String itemId = (String) itemData.get("id");
            Transaction t = new Transaction(
                "",
                username,
                idNumber,
                (String) itemData.get("name"),
                (String) itemData.get("qrCode"),
                1,
                sdf.format(now),
                "Borrowed",
                dueDate
            );
            firebaseManager.addTransaction(t, success -> {
                // Update item with borrower details and due date
                firebaseManager.updateItemBorrower(itemId, username, idNumber, dueDate, s -> {});
            });
        }
        Toast.makeText(this, "Items added to your history", Toast.LENGTH_SHORT).show();
        setupDashboard(true);
    }

    private void setupRefreshLayout() {
        binding.swipeRefresh.setColorSchemeResources(R.color.neon_blue);
        binding.swipeRefresh.setOnRefreshListener(() -> setupDashboard(true));
    }

    private void setupRoleBasedUI() {
        boolean isAdmin = "Admin".equals(userRole);
        if (!isAdmin) {
            MenuItem reportsItem = binding.bottomNav.getMenu().findItem(R.id.nav_reports);
            if (reportsItem != null) reportsItem.setVisible(false);
            binding.cardDefective.setVisibility(View.GONE);
            binding.cardScanQR.setVisibility(View.GONE);
            isShowingOverallLogs = false;
            binding.tvActivityLogsHeader.setText("Your Activity Logs");
        } else {
            binding.tvActivityLogsHeader.setText("Activity Logs");
            binding.cardScanQR.setVisibility(View.VISIBLE);
        }

        String idLabel = isAdmin ? "Admin ID: " : "Student ID: ";
        if (idNumber != null && !idNumber.isEmpty()) {
            binding.tvAdminNumberDisplay.setVisibility(View.VISIBLE);
            binding.tvAdminNumberDisplay.setText(idLabel + idNumber);
        } else {
            binding.tvAdminNumberDisplay.setVisibility(View.VISIBLE);
            binding.tvAdminNumberDisplay.setText(idLabel + "N/A");
        }
    }

    private void setupDashboard(boolean showSpinner) {
        if (showSpinner) binding.swipeRefresh.setRefreshing(true);
        binding.tvUserDisplayName.setText(username != null ? username : "User");

        firebaseManager.getAllItems(items -> {
            int totalAssets = 0;
            int totalUnitsInStock = 0;
            int defectiveCount = 0;
            for (com.example.mtracker.models.InventoryItem item : items) {
                // Total Assets should be updated (decreased) when an item is borrowed
                if (!"Borrowed".equalsIgnoreCase(item.getStatus())) {
                    totalAssets++;
                }

                if ("Available".equals(item.getStatus())) totalUnitsInStock += item.getQuantity();
                if ("Defective".equalsIgnoreCase(item.getCondition())) defectiveCount++;
            }
            binding.tvTotalItems.setText(String.valueOf(totalAssets));
            binding.tvAvailableItems.setText(String.valueOf(totalUnitsInStock));
            binding.tvMissingItems.setText(String.valueOf(defectiveCount));
        });

        firebaseManager.getAllTransactions(transactions -> {
            this.allTransactions = transactions;
            updateDashboardStatsAndLogs();
            binding.swipeRefresh.setRefreshing(false);
        });
    }

    private void updateDashboardStatsAndLogs() {
        Map<String, Transaction> activeBorrows = new HashMap<>(); // QR -> Transaction

        // Find active borrows: Latest transaction for each unique item that is "Borrowed"
        List<Transaction> sortedByDate = new ArrayList<>(allTransactions);
        Collections.sort(sortedByDate, (t1, t2) -> t1.getDate().compareTo(t2.getDate()));

        for (Transaction t : sortedByDate) {
            if (t.getQrCode() == null || t.getQrCode().isEmpty()) continue;
            if ("Borrowed".equalsIgnoreCase(t.getStatus())) {
                activeBorrows.put(t.getQrCode(), t);
            } else if (t.getStatus() != null && t.getStatus().startsWith("Returned")) {
                activeBorrows.remove(t.getQrCode());
            }
        }

        int borrowedCount = 0;
        int overdueCount = 0;
        List<Transaction> filteredLogs = new ArrayList<>();

        for (Transaction t : activeBorrows.values()) {
            boolean isOwn = idNumber != null && idNumber.equalsIgnoreCase(t.getStudentId());
            if (isShowingOverallLogs || isOwn) {
                borrowedCount++;
                if (t.isOverdue()) {
                    overdueCount++;
                }
                filteredLogs.add(t);
            }
        }
        
        // Sort display logs newest first
        Collections.sort(filteredLogs, (t1, t2) -> t2.getDate().compareTo(t1.getDate()));

        binding.tvBorrowedItems.setText(String.valueOf(borrowedCount));
        binding.tvOverdueItems.setText(String.valueOf(overdueCount));
        binding.tvLogToggle.setText(isShowingOverallLogs ? "Show My Activity" : "Show Overall");
        binding.tvLogToggle.setVisibility("Admin".equals(userRole) ? View.VISIBLE : View.GONE);

        int takeCount = Math.min(filteredLogs.size(), 10);
        TransactionAdapter recentAdapter = new TransactionAdapter(filteredLogs.subList(0, takeCount));
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(this));
        binding.rvRecentTransactions.setAdapter(recentAdapter);
    }

    private void setupListeners() {
        binding.btnLogout.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            finish();
        });

        binding.btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            intent.putExtra("USER_ROLE", userRole);
            intent.putExtra("USERNAME", username);
            intent.putExtra("ADMIN_NUMBER", idNumber);
            startActivity(intent);
        });

        binding.btnScanQR.setOnClickListener(v -> {
            Intent intent = new Intent(this, ScanActivity.class);
            intent.putExtra("USER_ROLE", userRole);
            intent.putExtra("USERNAME", username);
            intent.putExtra("ADMIN_NUMBER", idNumber);
            startActivity(intent);
        });

        binding.btnInventory.setOnClickListener(v -> {
            Intent intent = new Intent(this, InventoryActivity.class);
            intent.putExtra("USER_ROLE", userRole);
            intent.putExtra("USERNAME", username);
            intent.putExtra("ADMIN_NUMBER", idNumber);
            startActivity(intent);
        });

        binding.btnQuickHistory.setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryActivity.class);
            intent.putExtra("USER_ROLE", userRole);
            intent.putExtra("USERNAME", username);
            intent.putExtra("ADMIN_NUMBER", idNumber);
            startActivity(intent);
        });

        binding.tvLogToggle.setOnClickListener(v -> {
            isShowingOverallLogs = !isShowingOverallLogs;
            updateDashboardStatsAndLogs();
        });

        binding.bottomNav.setSelectedItemId(R.id.nav_home);
        binding.bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) return true;
            Intent intent = null;
            if (itemId == R.id.nav_inventory) intent = new Intent(this, InventoryActivity.class);
            else if (itemId == R.id.nav_history) intent = new Intent(this, HistoryActivity.class);
            else if (itemId == R.id.nav_reports) intent = new Intent(this, ReportsActivity.class);
            
            if (intent != null) {
                intent.putExtra("USER_ROLE", userRole);
                intent.putExtra("USERNAME", username);
                intent.putExtra("ADMIN_NUMBER", idNumber);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (requestListener != null) requestListener.remove();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (userRole != null) {
            setupDashboard(false);
            setupRoleBasedUI();
            binding.bottomNav.setSelectedItemId(R.id.nav_home);
        }
    }
}
